package se.su.camel;

import org.apache.camel.builder.RouteBuilder;

/**
 * A Camel Java DSL Router
 */
public class MyRouteBuilder extends RouteBuilder {

    /**
     * Let's configure the Camel routing rules using Java code...
     */
    public void configure() {

        from("file:/tmp/CamelTraining1/in")
        .to("file:/tmp/CamelTraining1/out");

    }
}
