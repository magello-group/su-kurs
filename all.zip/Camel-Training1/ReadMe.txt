Camel Java Router Project
=========================

To build this project use

    mvn clean install

